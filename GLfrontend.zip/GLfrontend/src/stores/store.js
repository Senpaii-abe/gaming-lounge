import { reactive } from 'vue';

const store = reactive({
  selectedOptions: [],
  gameTitles: [],
});

export default store;