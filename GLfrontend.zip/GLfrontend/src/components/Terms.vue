<template>
  <div class="bg-[#29172D] terms-and-conditions">
    <div class="p-4">
      <h1>Gaming Lounge Terms and Conditions</h1>
      <p><strong>Effective Date:</strong> August 31, 2023</p>
      <br>
      <h3>1. Introduction</h3>
      <p>Welcome to Gaming Lounge, a community platform dedicated to gaming enthusiasts. By accessing our website, you agree to comply with these Terms and Conditions.</p>
  
      <h3>2. User Accounts</h3>
      <p>a. Registration: Users must provide accurate information during registration.</p>
      <p>b. Security: Users are responsible for maintaining the confidentiality of their account.</p>
  
      <h3>3. Use of the Platform</h3>
      <p>a. Community Guidelines Users must adhere to our community guidelines, which promote respectful and constructive interaction.</p>
      <p>b. Game Selection: Users can select and participate in game categories and specific games as per their preference.</p>
  
      <h3>4. Hate Speech Detection</h3>
      <p>a. Monitoring: We actively monitor the platform for hate speech and abusive behavior.</p>
      <p>b. Consequences: Users found engaging in hate speech will face immediate account suspension or termination.</p>
  
      <h3>5. Beta Testing</h3>
      <p>a. Application: Users may apply for beta testing of games.</p>
      <p>b. Confidentiality: Beta testers must adhere to confidentiality agreements related to the beta games.</p>
  
      <h3>6. Intellectual Property</h3>
      <p>All content on Gaming Lounge, including text, graphics, and logos, is owned by us or our licensors and is protected by intellectual property laws.</p>
  
      <h3>7. Disclaimers</h3>
      <p>Gaming Lounge is provided "as is" without any warranties, express or implied. We do not guarantee the accuracy, completeness, or usefulness of any information on the platform.</p>
  
      <h3>8. Limitation of Liability</h3>
      <p>We shall not be liable for any damages arising out of your use of Gaming Lounge.</p>
  
      <h3>9. User Content</h3>
      <p>Users are responsible for their content, including posts, comments, and any data uploaded.</p>
  
      <h3>10. Prohibited Activities</h3>
      <p>Users must not engage in illegal activities, breach security, or exploit the platform for unauthorized purposes.</p>
  
      <h3>11. Termination</h3>
      <p>We reserve the right to terminate or suspend access to our platform for breach of these Terms and Conditions.</p>
  
      <h3>12. Changes to Terms</h3>
      <p>We may revise these Terms and Conditions periodically and will provide notice of any significant changes.</p>
  
      <h3>13. Governing Law</h3>
      <p>These Terms shall be governed by the laws of the Philippines.</p>
  
      <h3>14. Contact Us</h3>
      <p>For any queries regarding these Terms, please contact us at gamingglounge@gmail.com.</p>
    </div>
  </div>
  </template>
  
  <style scoped>
  .terms-and-conditions {
    padding: 20px;
    border: 1px solid #ccc;

    max-width: 1000px;
    margin: auto;
  
    font-size: 14px;
    height: 100%;
    overflow-y: auto;
  }

  h1{
    font-size: 22px;
    font-weight: bold;
    text-align: center;
  }
  .terms-and-conditions h3 {

    color: #f9f9f9;
    font-size: 20px;
    font-weight: bold;
  }
  
  .terms-and-conditions p {
    margin-top: 5px;
    font-size: 18px;

  }
  
  .terms-and-conditions li {
    margin-top: 5px;
    font-size: 18px;
    list-style-type: none;
  }
  </style>