<template>

<div class="bg-[#29172D] privacy-policy">
 
  <div class="p-4">
      <h1>Gaming Lounge Privacy Policy</h1>
      <p >Effective Date: August 31, 2023</p>
      <br>
  
      <h3 class="">1. Introduction</h3>
      <p>Welcome to Gaming Lounge, a community-based platform for gamers. We respect your privacy and are committed to protecting your personal data. This policy outlines our practices regarding data collection, use, and sharing.</p>
  
      <h3>2. Information We Collect</h3>
      <p >a. Personal Information:Includes your name, email address, and any other information you provide when registering.</p>
      <p >b. Gaming Preferences: Details about your game categories and specific games of interest.</p>
      <p >c. Community Interactions: Posts, comments, and interactions with other users.</p>
      <p>d. Beta Testing Applications: Information submitted when applying for game beta testing.</p>
  
      <h3>3. How We Use Your Information</h3>
      <p>Your data is used to:</p>
      <ul>
        <li>Personalize your experience on Gaming Lounge.</li>
        <li>Connect you with suitable gaming communities and beta testing opportunities.</li>
        <li>Improve our platform and services.</li>
      </ul>
  
      <h3>4. Sharing Your Information</h3>
      <p>We may share your information:</p>
      <ul>
        <li>With law enforcement if required by law.</li>
        <li>With third-party service providers assisting us in platform operations.</li>
      </ul>
  
      <h3>5. Data Security</h3>
      <p>We implement robust security measures to protect your data from unauthorized access, alteration, or destruction.</p>
  
      <h3>6. Your Rights</h3>
      <p>You have the right to:</p>
      <ul>
        <li>Access your personal data.</li>
        <li>Request correction or deletion of your data.</li>
        <li>Opt-out of certain data uses.</li>
      </ul>
  
      <h3>7. Cookies and Tracking</h3>
      <p>We use cookies to improve your experience and analyze site traffic. You may disable cookies in your browser settings.</p>
  
      <h3>8. Children’s Privacy</h3>
      <p>Gaming Lounge is not intended for children under the age of 10 below. We do not knowingly collect data from children.</p>
  
      <h3>9. Changes to This Policy</h3>
      <p>We may update this policy periodically. We will notify you of significant changes via email or on our website.</p>
  
      <h3>10. Contact Us</h3>
      <p>If you have any questions about this policy, please contact us at gamingglounge@gmail.com.</p>
    </div>
    </div>
  </template>
  
  <style scoped>
  .privacy-policy {
    padding: 20px;
    border: 1px solid #ccc;
   
    max-width: 1000px;
    margin: auto;
    font-size: 14px;
    height: 100%;
    overflow-y: auto;
  }

  h1{
    font-size: 22px;
    font-weight: bold;
    text-align: center;
  }
  .privacy-policy h3 {

    color: #f9f9f9;
    font-size: 20px;
    font-weight: bold;
  }
  
  .privacy-policy p {
    margin-top: 5px;
    font-size: 18px;

  }
  
  .privacy-policy li {
    margin-top: 5px;
    font-size: 18px;
    list-style-type: none;
  }
  </style>